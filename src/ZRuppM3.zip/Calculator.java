public interface Calculator {

    /*  I don't think calculating the average grade is actually a healthy thing to do
        since it may encourage climbers to avoid logging lower grade climbs to boost
        the average grade climbed. I'm keeping it here for now, because I will be using
        this interface to calculate other, more meaningful statistics in the future.
     */
    Grade calculateAvgGrade(ClimbLog climbList);
}
