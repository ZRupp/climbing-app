public class GymBoulder extends GymClimb {


    GymBoulder(String name, Face faceType, Grade gradeOfficial, Grade gradeFeel, boolean sent, int attempts, String color,
               String wallName){
        super(name, faceType, gradeOfficial, gradeFeel, sent, attempts, color, wallName);
    }

}
