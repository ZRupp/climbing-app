abstract class OutdoorClimb extends Climb{
    private String rockType;
    private String location;
    OutdoorClimb(String name, String style, int gradeOfficial, int gradeFeel, boolean sent, int attempts,
                 String rockType, String location){
        super(name, style, gradeOfficial, gradeFeel, sent, attempts);
        this.rockType = rockType;
        this.location = location;
    }

    public String getRockType(){
        return rockType;
    }

    public void setRockType(String rockType){
        this.rockType = rockType;
    }

    public String getLocation(){
        return location;
    }

    public void setLocation(String location){
        this.location = location;
    }

    @Override
    public String toString(){
        {
            String s = "";
            s += String.format("Name: %s\tOfficial Grade: 5.%s\t\tYour Grade: 5.%s\n", getName(), getGradeOfficial(),
                    getGradeFeel());
            s += String.format("Style: %s\t\t\tFlashed: %s\t\t\tAttempts: %s\n", getStyle(), isFlashed(), getAttempts());
            return s;
        }
    }


    @Override
    public boolean equals(Object o){
        if (this == o){
            return true;
        }

        if (!(o instanceof OutdoorClimb)){
            return false;
        }

        OutdoorClimb otherClimb = (OutdoorClimb) o;

        return getName().equals(otherClimb.getName())
                && Integer.compare(getGradeOfficial(), otherClimb.getGradeOfficial()) == 0
                && rockType.equals(otherClimb.rockType) && location.equals(otherClimb.location);
    }
}
