import java.util.ArrayList;

public class Driver {

    public static void main(String[] args) {
        ArrayList<Climber> climbers = new ArrayList<>();
        Climber climber1 = new Climber("Dude", "Guy", 29);
        Climber climber2 = new Climber("Mister", "Monster", 999, 250, 56.5);

        climbers.add(climber1);
        climbers.add(climber2);

        Climb climb1 = new GymBoulder("Head Crusher", "Slab", 2, 2, false,
                3, "Blue", "Slab Wall");

        Climb climb2 = new OutdoorBoulder("Mind the Crack", "Crack", 11, 13,
                false, 12, "granite", "Bishop");

        Climb climb3 = new GymRoute("FingerBreaker", "Vert", 11, 10, true, 1, "yellow", "Vert Wall");

        Climb climb4 = new OutdoorRoute("OingoBoingo", "Overhang", 12, 13, false, 12, "Sandstone", "Berkeley", 1);

        ArrayList<Climb> climbs = new ArrayList<>();
        climbs.add(climb1);
        climbs.add(climb2);
        climbs.add(climb3);
        climbs.add(climb4);
        System.out.println("Registered Climbers: ");
        System.out.println(climbers);

        System.out.println("Registered Climbs: ");
        System.out.println(climbs);
        climber1.logClimb(climbs.get(0));
        climber1.logClimb(climbs.get(1));
        climber2.logClimb(climbs.get(2));
        climber2.logClimb(climbs.get(3));

        System.out.println(climbers.get(0));
        climbers.get(0).printClimbs();

        System.out.println(climbers.get(1));
        climbers.get(1).printClimbs();

        System.out.println(climbers.get(0));
        climbers.get(0).logClimb(climbs.get(0));

        climber1.printClimbs();

        System.out.println(climbs.get(3).getAttempts());

        System.out.println("LOGGING 5 NEW ATTEMPTS:");
        climbs.get(3).logAttempts(5);

        System.out.println(climbs.get(3).getAttempts());
        System.out.println();
        System.out.println("CALCULATING DUDE GUY'S AVERAGE BOULDERING GRADE");
        System.out.printf("Climber: %s %s\n", climbers.get(0).getFirstName(), climbers.get(0).getLastName());
        System.out.printf("Average Boulder Grade: v%s\n", climbers.get(0).calculateAvgProblemGrade());
        System.out.println();

        System.out.println("CALCULATING MISTER MONSTER'S AVERAGE ROUTE GRADE");
        System.out.printf("Climber: %s %s\n", climbers.get(1).getFirstName(), climbers.get(1).getLastName());
        climbers.get(1).printAvgGrades();



    }
}
