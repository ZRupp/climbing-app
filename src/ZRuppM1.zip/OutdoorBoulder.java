public class OutdoorBoulder extends OutdoorClimb {

    OutdoorBoulder(String name, String style, int gradeOfficial, int gradeFeel, boolean sent, int attempts,
                 String rockType, String location){
        super(name, style, gradeOfficial, gradeFeel, sent, attempts, rockType, location);
    }

}
