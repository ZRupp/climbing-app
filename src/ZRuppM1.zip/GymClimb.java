abstract class GymClimb extends Climb {
    private String color;
    private String wallName;
    GymClimb(String name, String style, int gradeOfficial, int gradeFeel, boolean sent, int attempts, String color,
             String wallName) {
        super(name, style, gradeOfficial, gradeFeel, sent, attempts);
        this.color = color;
        this.wallName = wallName;
    }


    public String getColor(){
        return color;
    }

    public void setColor(String color){
        this.color = color;
    }

    public String getWallName(){
        return wallName;
    }

    public void setWallName(String wallName){
        this.wallName = wallName;
    }

    @Override
    public String toString(){
        {
            String s = "";
            s += String.format("Name: %s\tOfficial Grade: v%s\t\tYour Grade: v%s\n", getName(), getGradeOfficial(),
                    getGradeFeel());
            s += String.format("Style: %s\t\t\tFlashed: %s\t\t\tAttempts: %s\n", getStyle(), isFlashed(), getAttempts());
            return s;
        }
    }

    @Override
    public boolean equals(Object o){
        if (this == o){
            return true;
        }

        if (!(o instanceof GymClimb)){
            return false;
        }

        GymClimb otherBoulder = (GymClimb) o;

        return getName().equals(otherBoulder.getName())
                && Integer.compare(getGradeOfficial(), otherBoulder.getGradeOfficial()) == 0
                && color.equals(otherBoulder.color) && wallName.equals(otherBoulder.wallName);
    }

}
