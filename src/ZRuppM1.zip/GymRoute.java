public class GymRoute extends GymClimb {

    GymRoute(String name, String style, int gradeOfficial, int gradeFeel, boolean sent, int attempts, String color,
               String wallName){
        super(name, style, gradeOfficial, gradeFeel, sent, attempts, color, wallName);
    }


}
