public class OutdoorRoute extends OutdoorClimb {

    private int numberOfPitches;

    OutdoorRoute(String name, String style, int gradeOfficial, int gradeFeel, boolean sent, int attempts,
                 String rockType, String location, int numberOfPitches){
        super(name, style, gradeOfficial, gradeFeel, sent, attempts, rockType, location);
        this.numberOfPitches = numberOfPitches;
    }

    public int getNumberOfPitches(){
        return numberOfPitches;
    }

}
