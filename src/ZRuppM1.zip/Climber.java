import java.time.LocalDate;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;

public class Climber {
    private static final AtomicInteger numberOfClimbers = new AtomicInteger(0);
    private int climberID;
    private String firstName;
    private String lastName;
    private int age;
    private double weightInPounds;
    private double bodyFatPercentage;
    private LocalDate startDate;
    private ArrayList<Climb> climbs;

    Climber(String firstName, String lastName, int age, double weightInPounds, double bodyFatPercentage){
        climberID = numberOfClimbers.incrementAndGet();
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.weightInPounds = weightInPounds;
        this.bodyFatPercentage = bodyFatPercentage;
        startDate = LocalDate.now();
        climbs = new ArrayList<>();

    }

    Climber(String firstName, String lastName, int age, double weightInPounds){
        this(firstName, lastName, age, weightInPounds, 0);
    }

    Climber(String firstName, String lastName, int age){
        this(firstName, lastName, age, 0, 0);
    }

    // Logs a climb for the climber.
    public void logClimb(Climb climbLogged){
        if (climbs.contains(climbLogged)){
            climbs.get(climbs.indexOf(climbLogged)).logAttempts(climbLogged.getAttempts());
        } else {
            climbs.add(climbLogged);
        }
    }

    public void printClimbs(){
        System.out.println("Climbs logged:");
        for (Climb climb : climbs){
            System.out.println(climb);
        }
    }

    //Calculates the average problem grade for the climber
    public int calculateAvgProblemGrade(){
        int count = 0;
        int sum = 0;
        for (Climb climb : climbs){
            if (climb instanceof GymBoulder || climb instanceof OutdoorBoulder){
                count++;
                sum += climb.getGradeOfficial();
            }
        }

        return (count > 0 ? sum/count : -1);
    }

    /* Calculates the average route grade for the climber.
       This will need to be reworked to accommodate grades like 5.11a, 5.11b, 5.11c etc.
       Some kind of dictionary mapping would probably work. Route grades will similarly
       need to be reconsidered. I'll also potentially combine both this method and the
       above returning a Javatuple containing each average.
    */
    public int calculateAvgRouteGrade(){
        int count = 0;
        int sum = 0;
        for (Climb climb : climbs){
            if (climb instanceof GymRoute || climb instanceof OutdoorRoute){
                count++;
                sum += climb.getGradeOfficial();
            }
        }

        return (count > 0 ? sum/count : -1);
    }

    public void printAvgGrades(){
        int problemGrade = calculateAvgProblemGrade();
        int routeGrade = calculateAvgRouteGrade();
        if (problemGrade > 0){
            System.out.printf("Average Boulder Grade: v%s\n", problemGrade);
        }
        if (routeGrade > 0){
            System.out.printf("Average Route Grade: 5.%s\n", routeGrade);
        }
    }

    public int getClimberID(){
        return climberID;
    }

    public String getFirstName(){
        return firstName;
    }

    public void setFirstName(String firstName){
        this.firstName = firstName;
    }

    public String getLastName(){
        return lastName;
    }

    public void setLastName(String lastName){
        this.lastName = lastName;
    }

    public int getAge(){
        return age;
    }

    public void setAge(int age){
        this.age = age;
    }

    public double getWeightInPounds(){
        return weightInPounds;
    }

    public void setWeightInPounds(float weightInPounds){
        this.weightInPounds = weightInPounds;
    }

    public double getBodyFatPercentage(){
        return bodyFatPercentage;
    }

    public void setBodyFatPercentage(float bodyFatPercentage) {
        this.bodyFatPercentage = bodyFatPercentage;
    }

    public LocalDate getStartDate(){
        return startDate;
    }

    @Override
    public String toString(){
        String s = "";
        s += String.format("%s %s (%s)\n", firstName, lastName, climberID);
        s += String.format("Age: %s\nWeight: %s\n", age, (weightInPounds > 0 ? weightInPounds : "None given"));
        s += String.format("Enrollment Date: %s\n", startDate);

        return s;
    }

    @Override
    public boolean equals(Object o){
        if (this == o){
            return true;
        }

        if (!(o instanceof Climber)){
            return false;
        }

        Climber otherClimber = (Climber) o;

        return Integer.compare(climberID, otherClimber.climberID) == 0;
    }
}
