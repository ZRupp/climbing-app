abstract class Climb {
    private String name;
    private String style;
    private int gradeOfficial;
    private int gradeFeel;
    private boolean sent;
    private int attempts = 0;

    Climb(String name, String style, int gradeOfficial, int gradeFeel, boolean sent, int attempts){
        this.name = name;
        this.style = style;
        this.gradeOfficial = gradeOfficial;
        this.gradeFeel = gradeFeel;
        this.sent = sent;
        this.attempts = attempts;
    }

    // Returns true if the climb has been flashed.
    public boolean isFlashed(){
        return getAttempts() == 1 && getSent();
    }

    // Logs a climb attempt.
    public void logAttempts(int newAttempts){
        attempts += newAttempts;
    }

    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }

    public String getStyle(){
        return style;
    }

    public void setStyle(String style){
        this.style = style;
    }

    public boolean getSent(){
        return sent;
    }

    public void setSent(boolean sent){
        this.sent = sent;
    }

    public int getGradeOfficial(){
        return gradeOfficial;
    }

    public void setGradeOfficial(int gradeOfficial){
        this.gradeOfficial = gradeOfficial;
    }

    public int getGradeFeel(){
        return gradeFeel;
    }

    public void setGradeFeel(int gradeFeel){
        this.gradeFeel = gradeFeel;
    }

    public int getAttempts(){
        return attempts;
    }

    @Override
    public abstract String toString();

    @Override
    public abstract boolean equals(Object otherClimb);
}
