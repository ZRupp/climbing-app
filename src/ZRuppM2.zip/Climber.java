import java.time.LocalDate;
import java.util.ArrayList;

public class Climber implements Comparable<Climber>{
    private static int numberOfClimbers = 0; // M2 HOMEWORK STATIC
    private String climberID;
    private String firstName;
    private String lastName;
    private int age;
    private double weightInPounds;
    private double bodyFatPercentage;
    private LocalDate startDate;
    private ArrayList<Climb> climbs;

    public Climber(String firstName, String lastName, int age, double weightInPounds, double bodyFatPercentage){
        Climber.numberOfClimbers++;
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.weightInPounds = weightInPounds;
        this.bodyFatPercentage = bodyFatPercentage;
        startDate = LocalDate.now();
        climbs = new ArrayList<>();
        climberID = String.format("%s%s%s%s%s", firstName.charAt(0), lastName.charAt(0), startDate.getMonthValue(),
                startDate.getDayOfMonth(), startDate.getYear());

    }

    public Climber(String firstName, String lastName, int age, double weightInPounds){
        this(firstName, lastName, age, weightInPounds, 0);
    }

    public Climber(String firstName, String lastName, int age){
        this(firstName, lastName, age, 0, 0);
    }

    public static int getNumOfClimbers(){ // M2 HOMEWORK STATIC
        return numberOfClimbers;
    } // M2 HOMEWORK STATIC

    // Logs a climb for the climber.
    public void logClimb(Climb climbLogged){
        if (climbs.contains(climbLogged)){
            climbs.get(climbs.indexOf(climbLogged)).logAttempts(climbLogged.getAttempts());
        } else {
            climbs.add(climbLogged);
        }
    }

    public void printClimbs(){
        System.out.println("Climbs logged:");
        for (Climb climb : climbs){
            System.out.println(climb);
        }
    }

    //Calculates the average problem grade for the climber
    private Grade calculateAvgProblemGrade(){ // M2 HOMEWORK ENUM USE
        int count = 0;
        int sum = 0;
        for (Climb climb : climbs){
            if (climb instanceof GymBoulder || climb instanceof OutdoorBoulder){
                count++;
                sum += climb.getGradeOfficial().getNumericEquivalent();
            }
        }

        return Grade.valueOf("V".concat(Integer.toString((count > 0 ? sum/count : -1))));
    }

    /* Calculates the average route grade for the climber.
    */
    private Grade calculateAvgRouteGrade(){ // M2 HOMEWORK ENUM USE
        int count = 0;
        int sum = 0;
        for (Climb climb : climbs){
            if (climb instanceof GymRoute || climb instanceof OutdoorRoute){
                count++;
                sum += climb.getGradeOfficial().getNumericEquivalent();
            }
        }

        return convertAvgRouteToGrade((count > 0? sum/count : -1));
    }

    private Grade convertAvgRouteToGrade(int avgRouteGrade){ // M2 HOMEWORK ENUM USE

        if (avgRouteGrade <=9){
            return  Grade.valueOf("5.".concat(Integer.toString(avgRouteGrade)));
        } else {

            int minNumericGrade = 10;
            int checkedGrade;
            int maxNumericGrade = 15;

            for (int i = 0; i <= maxNumericGrade - minNumericGrade; i++){
                checkedGrade = minNumericGrade + i;
                int result = avgRouteGrade - (4*i) - checkedGrade;
                if (result <= 4){
                    String modifier;

                    switch (result){
                        case 1:
                            modifier = "A";
                            break;
                        case 2:
                            modifier = "B";
                            break;
                        case 3:
                            modifier = "C";
                            break;
                        case 4:
                            modifier = "D";
                            break;
                        default:
                            modifier = "E"; // This is bad maybe. Will cause an IllegalArgumentException to be thrown.
                    }
                    return Grade.valueOf("YDS".concat(Integer.toString(checkedGrade).concat(modifier)));
                }
            }

        }
        return null;
    }

    public void printAvgGrades(){ // HOMEWORK M2 ENUM USE
        try{
            Grade problemGrade = calculateAvgProblemGrade();
            System.out.printf("Average Boulder Grade: %s\n", problemGrade.getRepresentation());
        } catch(IllegalArgumentException e){
            System.out.println("Average Boulder Grade: None");
        }

        try {
            Grade routeGrade = calculateAvgRouteGrade();
            System.out.printf("Average Route Grade: %s\n", routeGrade.getRepresentation());
        } catch(IllegalArgumentException e){
            System.out.println("Average Route Grade: None");
        }
    }

    public String getClimberID(){
        return climberID;
    }

    public String getFirstName(){
        return firstName;
    }

    public void setFirstName(String firstName){
        this.firstName = firstName;
    }

    public String getLastName(){
        return lastName;
    }

    public void setLastName(String lastName){
        this.lastName = lastName;
    }

    public int getAge(){
        return age;
    }

    public void setAge(int age) {
        if (age < 6) {
            System.out.println("Climber is too young to register.");
        } else {
            this.age = age;
        }
    }

    public double getWeightInPounds(){
        return weightInPounds;
    }

    public void setWeightInPounds(float weightInPounds){
        if (weightInPounds < 0){
            System.out.println("Invalid weight.");
        } else {
            this.weightInPounds = weightInPounds;
        }
    }

    public double getBodyFatPercentage(){
        return bodyFatPercentage;
    }

    public void setBodyFatPercentage(float bodyFatPercentage) {
        if (bodyFatPercentage < 0 || bodyFatPercentage > 80) {
            System.out.println("Invalid body fat percentage.");
        } else {
            this.bodyFatPercentage = bodyFatPercentage;
        }
    }

    public LocalDate getStartDate(){
        return startDate;
    }

    @Override
    public String toString(){
        String s = "";
        s += String.format("%s %s (%s)\n", firstName, lastName, climberID);
        s += String.format("Age: %s\nWeight: %s\n", age, (weightInPounds > 0 ? weightInPounds : "None given"));
        s += String.format("Enrollment Date: %s\n", startDate);

        return s;
    }

    @Override
    public boolean equals(Object o){
        if (this == o){
            return true;
        }

        if (!(o instanceof Climber)){
            return false;
        }

        Climber otherClimber = (Climber) o;

        return climberID.equals(otherClimber.climberID);
    }

    @Override
    public int compareTo(Climber otherClimber){
        if (firstName.equals(otherClimber.firstName) && lastName.equals(otherClimber.lastName)){
            return climberID.compareTo(otherClimber.climberID);
        } else {
            return firstName.concat(lastName).compareTo(otherClimber.firstName.concat(otherClimber.lastName));
        }
    }
}
