public class OutdoorBoulder extends OutdoorClimb {

    OutdoorBoulder(String name, Face faceType, Grade gradeOfficial, Grade gradeFeel, boolean sent, int attempts,
                   String rockType, String location){
        super(name, faceType, gradeOfficial, gradeFeel, sent, attempts, rockType, location);
    }

}
