import java.util.ArrayList;
import java.util.Collections;

public class Driver {

    public static void main(String[] args) {
        ArrayList<Climber> climbers = new ArrayList<>();
        Climber climber1 = new Climber("Dude", "Guy", 29);
        Climber climber2 = new Climber("Mister", "Monster", 999, 250, 56.5);
        Climber climber3 = new Climber("Aloe", "Vera", 32);
        Climber climber4 = new Climber("Edric", "Garcia", 28);


        climbers.add(climber1);
        climbers.add(climber2);
        climbers.add(climber3);
        climbers.add(climber4);
        Collections.sort(climbers);

        Climb climb1 = new GymBoulder("Head Crusher", Climb.Face.SLAB, Grade.V2, Grade.V2, false,
                3, "Blue", "Slab Wall");

        Climb climb2 = new OutdoorBoulder("Mind the Crack", Climb.Face.OVERHANG, Grade.V10, Grade.V10,
                false, 12, "granite", "Bishop");

        Climb climb3 = new GymRoute("FingerBreaker", Climb.Face.VERT, Grade.YDS10A, Grade.YDS10A, true, 1, "yellow", "Vert Wall");

        Climb climb4 = new OutdoorRoute("OingoBoingo", Climb.Face.OVERHANG, Grade.YDS13C, Grade.YDS13A, false, 12, "Sandstone", "Berkeley", 1);

        ArrayList<Climb> climbs = new ArrayList<>();
        climbs.add(climb1);
        climbs.add(climb2);
        climbs.add(climb3);
        climbs.add(climb4);
        System.out.println("Registered Climbers: ");
        System.out.println(climbers);

        System.out.println("Registered Climbs: ");
        System.out.println(climbs);
        climbers.get(0).logClimb(climbs.get(0));
        climbers.get(0).logClimb(climbs.get(1));
        climbers.get(1).logClimb(climbs.get(2));
        climbers.get(1).logClimb(climbs.get(3));

        System.out.println(climbers.get(0));
        climbers.get(0).printClimbs();

        System.out.println(climbers.get(1));
        climbers.get(1).printClimbs();

        System.out.println();
        System.out.printf("CALCULATING %s'S AVERAGE GRADES\n", climbers.get(0).getFirstName().toUpperCase());
        System.out.printf("Climber: %s %s\n", climbers.get(0).getFirstName(), climbers.get(0).getLastName());
        climbers.get(0).printAvgGrades();
        System.out.println();

        System.out.printf("CALCULATING %s'S AVERAGE GRADES\n", climbers.get(1).getFirstName().toUpperCase());
        System.out.printf("Climber: %s %s\n", climbers.get(1).getFirstName(), climbers.get(1).getLastName());
        climbers.get(1).printAvgGrades();
        System.out.println();

        System.out.printf("Number of climbers: %s\n", Climber.getNumOfClimbers());

    }
}
